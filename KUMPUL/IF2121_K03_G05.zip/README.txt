# TubesLogif Battle Royale

Membuat sebuah battle royale game dengan menggunakan bahasa pemrograman
deklaratif Prolog (gunakan GNU Prolog).

![alt text](https://github.com/CLoouis/TubesLogif/blob/master/tubes.PNG)

Masukkan ['game.pl']
Ketik:
start. -- Untuk memulai permainan. 
quit. -- Keluar dari permainan
look. -- Melihat keadaan petak sekitar
n,s,e,w. -- Untuk berjalan kearah utara, selatan, timur, dan barat
tampilpeta. -- Menampilkan peta wilayah permainan
take(Object). -- Mengambil sebuah object
drop(Object). -- Menjatuhkan sebuah object
use(Object). -- Menggunakan sebuah object
attack. -- Menyerang musuh yang terdapat di petak yang sama
status. -- Menampilkan status permainan
savegame('FileName.pl'). -- Save permainan di FileName.pl
loadgame('FileName.pl'). -- Load permainan di FileName.pl